#!/bin/bash

# ---------------------------------------------------------
#   get_images_version       
#   回傳碼：
#                       0  = 
#                       1  = 
# ---------------------------------------------------------


#PROJECT_KEYWORD=$1

#if [ -z "$PROJECT_KEYWORD" ]; then
#    echo "Usage: $0 <project_keyword>"
#    exit 1
#fi

usage()
{
    cat <<EOF
Usage: get_traffic.sh [PARAM]

Known values for PARAM are:

  參數1 = [go_nuxt] : Required
EOF
}


source /opt/vcs/tools/utils/sshToolUtil.sh prod

get_all_project_version() {
    
    #local filter_pattern="(frontend|backend)-(prod|dev)"
    #local target_name=$1

    local result=$(ssh_function "docker ps  --format '{{.Image}}' | grep -E 'frontend|backend' | uniq")

    echo "$result"
}

get_all_project_version $1
