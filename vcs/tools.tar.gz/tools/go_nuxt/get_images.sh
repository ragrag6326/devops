#!/bin/bash

# ---------------------------------------------------------
#   get_images_version       
#   回傳碼：
#                       0  = 
#                       1  = 
# ---------------------------------------------------------


PROJECT_KEYWORD=$1

if [ -z "$PROJECT_KEYWORD" ]; then
    echo "Usage: $0 <project_keyword>"
    exit 1
fi

usage()
{
    cat <<EOF
Usage: get_traffic.sh [PARAM]

Known values for PARAM are:

  參數1 = [go_nuxt] : Required
EOF
}


source /opt/vcs/tools/utils/sshToolUtil.sh prod

get_version_list() {
    local result=$(ssh_function "docker images --format "{{.Repository}}:{{.Tag}}" | grep "$PROJECT_KEYWORD" | grep frontend-prod | cut -d '/' -f 2")
    echo "$result"
}

get_version_list
